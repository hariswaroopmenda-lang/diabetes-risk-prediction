"""Save readable results and figures from the actual experiment."""

import base64
import html
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import ConfusionMatrixDisplay, roc_curve, precision_recall_curve


def save_reports(data, comparison, audit, meta, y_test, scores, output):
    output = Path(output)
    figures = output / "figures"
    matrices = output / "confusion_matrices"
    figures.mkdir(exist_ok=True)
    matrices.mkdir(exist_ok=True)
    plt.rcParams.update({"figure.dpi": 140, "font.size": 10,
                         "axes.spines.top": False, "axes.spines.right": False})
    test = comparison[comparison.split == "test"]
    capacity = test[test.policy == "capacity_30_percent"].set_index("model")
    ax = capacity[["recall", "precision", "f1"]].plot.bar(
        figsize=(8, 4.5), color=["#167d9a", "#e59c39", "#6b77ba"], rot=0)
    ax.set(title="Untouched test set: screening at 30% capacity",
           xlabel="", ylabel="Score", ylim=(0, 1))
    ax.legend(["Recall", "Precision", "F1"], loc="upper right")
    plt.tight_layout()
    plt.savefig(figures / "model_comparison.png")
    plt.close()

    fig, axes = plt.subplots(1, 2, figsize=(10, 4.5))
    for name, values in scores.items():
        fpr, tpr, _ = roc_curve(y_test, values)
        axes[0].plot(fpr, tpr, label=name)
        precision, recall, _ = precision_recall_curve(y_test, values)
        axes[1].plot(recall, precision, label=name)
    axes[0].plot([0, 1], [0, 1], "--", color="gray")
    axes[1].axhline(float(np.mean(y_test)), linestyle="--", color="gray")
    axes[0].set(title="ROC curves", xlabel="False positive rate", ylabel="True positive rate")
    axes[1].set(title="Precision-recall curves", xlabel="Recall", ylabel="Precision")
    for ax in axes:
        ax.legend(fontsize=8)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1.02)
    fig.tight_layout()
    fig.savefig(figures / "roc_pr_curves.png")
    plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    data.Outcome.value_counts().sort_index().plot.bar(
        ax=axes[0], color=["#167d9a", "#e59c39"], rot=0)
    axes[0].set(title="Dataset class balance", xlabel="Outcome (0 / 1)", ylabel="Patients")
    audit.set_index("feature").missing_after_cleaning.plot.barh(ax=axes[1], color="#167d9a")
    axes[1].set(title="Missing measurements after zero handling", xlabel="Patients", ylabel="")
    fig.tight_layout()
    fig.savefig(figures / "data_overview.png")
    plt.close(fig)

    for _, row in test.iterrows():
        matrix = np.array([[row.tn, row.fp], [row.fn, row.tp]], dtype=int)
        name = row.model.lower().replace(" ", "_") + "_" + row.policy
        np.savetxt(matrices / f"{name}.csv", matrix, fmt="%d", delimiter=",")
        fig, ax = plt.subplots(figsize=(4.8, 4.4))
        ConfusionMatrixDisplay(matrix, display_labels=["Outcome 0", "Outcome 1"]).plot(
            ax=ax, cmap="Blues", colorbar=False)
        ax.set_title(f"{row.model}\n{row.policy.replace('_', ' ')}", fontsize=11)
        fig.tight_layout()
        fig.savefig(matrices / f"{name}.png")
        plt.close(fig)

    chosen = meta["test_capacity_results"]
    report = f"""DIABETES RISK PREDICTION
Course project report

What I set out to do
The project asks whether a model can help a clinic choose which patients to test
when only 30% of a walk-in batch can receive a blood test. I compared KNN,
Logistic Regression and a Decision Tree. The clinic's limit makes recall at 30%
capacity a useful measure: it tells us what share of positive cases in a batch
would be selected for testing.

The data
The CSV contains {meta['dataset_rows']} records: {meta['positive_rows']} with Outcome 1
and {meta['negative_rows']} with Outcome 0. It has eight input features and one
Outcome label. The assignment points to Kaggle [2]; the CSV included here is a
public copy from Plotly's dataset repository [3].

The dataset uses zero to stand for a missing glucose, blood pressure, skin
thickness, insulin or BMI measurement. I treated those zeros as missing and kept
zero pregnancies as a valid value. The median imputer learned its values from
training records only. KNN and Logistic Regression also use a scaler fitted on
the training records. The Decision Tree does not need scaling.

How I compared the models
I used stratified groups of {meta['train_rows']} training, {meta['validation_rows']}
validation and {meta['test_rows']} test records. A stratified split keeps a similar
share of each Outcome in every group [5]. Keeping preparation inside the model
pipeline helps prevent information from test records leaking into training [4].

The settings were KNN with 15 distance-weighted neighbours, Logistic Regression
with its default penalty and C=1, and a Decision Tree with maximum depth 4 and a
minimum of 10 records in each leaf. I used validation results to choose the model
and its cutoff. I left the test records aside until those choices were made.

Logistic Regression had the strongest validation recall under the 30% rule, so I
selected it. Precision and then average precision broke ties. Its validation
cutoff was {meta['threshold']:.6f}. I did not change the selected model after seeing
the test results, even though the Decision Tree happened to score better on this
one test batch.

One cutoff and the capacity rule serve different purposes. A patient above the
validation cutoff may still fall outside a batch's top 30%. For actual batch
screening, the app sorts the scores and selects floor(0.30 x batch size). Ties
follow the input row order. Batches smaller than four have no slots under this
strict rule.

Results on the held-back test records
The selected model chose {chosen['selected']} of {chosen['patients']} people, which is
within the 30% limit. Of the positive records, it found {chosen['tp']} and missed
{chosen['fn']}. It selected {chosen['fp']} negative records and correctly left
{chosen['tn']} negative records unselected.

Accuracy: {chosen['accuracy']:.1%}
Precision: {chosen['precision']:.1%} ({chosen['tp']} of {chosen['selected']} selected records were positive)
Recall at 30% capacity: {chosen['recall']:.1%} ({chosen['tp']} of {chosen['tp'] + chosen['fn']} positive records were selected)
F1 score: {chosen['f1']:.3f}
ROC AUC: {chosen['roc_auc']:.3f}
Average precision: {chosen['average_precision']:.3f}

The results file also reports all three models using a 0.5 cutoff, the cutoff
chosen from validation data, and the 30% capacity rule. Accuracy describes the
share of all decisions that were correct. Precision describes how often a
selected record was positive. Recall describes how many positive records were
selected. The confusion matrices show the same counts as the results above.

What these results do and do not tell us
These numbers describe one small split of this historical dataset. A different
split could produce different results, and this evaluation does not show how the
model would work for a rural clinic. The scores have not been calibrated as
individual medical risks, and they cannot diagnose anyone.

There is a practical problem with the assignment's proposed use: glucose and
insulin are already lab measurements. This project therefore does not show how
to screen patients before drawing blood. Clinical use would require suitable
inputs, representative outside validation, and review by health professionals.

How to run the project
Use Python 3.12. Install the packages with ``py -3.12 -m pip install -r requirements.txt``.
Run the console version with ``py -3.12 diabetes_prediction.py`` or open the app
with ``py -3.12 -m streamlit run app.py``. The app can enter one sample record or
rank a CSV batch under the 30% rule.

References
[1] Project guide supplied for this coursework, “Diabetes Risk Prediction Using
Machine Learning.” The guide describes the clinic problem and the 30% limit.
[2] Kaggle, Pima Indians Diabetes Database (assignment link):
https://www.kaggle.com/code/mragpavank/pima-indians-diabetes-database/input
[3] Plotly, diabetes.csv, the public copy used in this project:
https://github.com/plotly/datasets/blob/master/diabetes.csv
[4] Scikit-learn, “Common pitfalls and recommended practices”:
https://scikit-learn.org/stable/common_pitfalls.html
[5] Scikit-learn, ``train_test_split`` documentation:
https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html

Data file SHA-256: {meta['dataset_sha256']}
"""
    (output / "evaluation_report.txt").write_text(report, encoding="utf-8")

    def embedded_image(path, caption):
        encoded = base64.b64encode(path.read_bytes()).decode("ascii")
        return f'<figure><img src="data:image/png;base64,{encoded}" alt="{html.escape(caption)}"><figcaption>{html.escape(caption)}</figcaption></figure>'

    table = test[["model", "policy", "accuracy", "precision", "recall", "f1", "selected"]]
    table_html = table.to_html(index=False, float_format=lambda value: f"{value:.3f}")
    winner_matrix = matrices / (meta["selected_model"].lower().replace(" ", "_") +
                                "_capacity_30_percent.png")
    page = f"""<!doctype html><html lang="en"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Diabetes Risk Prediction — Project Report</title>
<style>body{{font:16px/1.65 system-ui,sans-serif;color:#203342;background:#f2f6f8;margin:0}}
main{{max-width:1000px;margin:auto;padding:42px 28px;background:white}}
h1{{font-size:38px;line-height:1.15;color:#12586e}}h2{{margin-top:32px;color:#12586e}}
.label{{text-transform:uppercase;letter-spacing:2px;font-size:12px;color:#52727d}}
.cards{{display:flex;gap:16px;flex-wrap:wrap}}.card{{background:#eaf4f5;padding:18px;flex:1;min-width:150px}}
.card strong{{display:block;font-size:28px;color:#12586e}}img{{max-width:100%;height:auto}}
figure{{margin:28px 0}}figcaption{{font-size:13px;color:#526570}}pre{{white-space:pre-wrap;font:14px/1.7 system-ui}}
.table{{overflow-x:auto}}table{{border-collapse:collapse;width:100%;font-size:13px}}th,td{{padding:9px;border-bottom:1px solid #d9e4e8;text-align:left}}
.note{{border-left:4px solid #e59c39;padding:12px 18px;background:#fff8ed}}
@media print{{body{{background:white}}main{{padding:0}}figure,table,.cards{{break-inside:avoid}}}}</style>
<main><div class="label">Course project / machine learning</div>
<h1>Diabetes risk prediction</h1><p>Comparing models and ranking a patient batch under a 30% testing limit.</p>
<div class="cards"><div class="card">Selected model<strong>{html.escape(meta['selected_model'])}</strong></div>
<div class="card">Test recall at capacity<strong>{chosen['recall']:.1%}</strong></div>
<div class="card">Selected / test patients<strong>{chosen['selected']} / {chosen['patients']}</strong></div></div>
<p class="note">This is a coursework demonstration. A model score is not a diagnosis or a calibrated medical risk.</p>
<h2>Dataset and missing measurements</h2>{embedded_image(figures / 'data_overview.png', 'Actual dataset counts before imputation.')}
<h2>Model comparison</h2>{embedded_image(figures / 'model_comparison.png', 'The winner was selected on validation data; this chart describes held-out test results.')}
<div class="table">{table_html}</div>
{embedded_image(figures / 'roc_pr_curves.png', 'Ranking performance across score thresholds on the test set.')}
<h2>Selected model: who was captured and missed?</h2>{embedded_image(winner_matrix, 'Rows are actual outcomes; columns are screening decisions at strict 30% capacity.')}
<h2>Method, results and limitations</h2><pre>{html.escape(report)}</pre>
<h2>References</h2><ol>
<li>Project guide supplied for this coursework: “Diabetes Risk Prediction Using Machine Learning.”</li>
<li><a href="https://www.kaggle.com/code/mragpavank/pima-indians-diabetes-database/input">Kaggle dataset page linked in the assignment</a>.</li>
<li><a href="https://github.com/plotly/datasets/blob/master/diabetes.csv">Plotly diabetes.csv</a>, the public copy used in this project.</li>
<li><a href="https://scikit-learn.org/stable/common_pitfalls.html">Scikit-learn: Common pitfalls and recommended practices</a>.</li>
<li><a href="https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html">Scikit-learn: train_test_split</a>.</li>
</ol></main></html>"""
    (output / "Project_Report.html").write_text(page, encoding="utf-8")
